<template>
	<div>
		<h1>Order now</h1>
		<hr>
	</div>
</template>

<script>
	export default {
		
	}
</script>